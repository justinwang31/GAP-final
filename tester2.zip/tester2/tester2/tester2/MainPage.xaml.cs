﻿using SkiaSharpFormsDemos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace tester2
{
    public partial class MainPage : HomeBasePage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
